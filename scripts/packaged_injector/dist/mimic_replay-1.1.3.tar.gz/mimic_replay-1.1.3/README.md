This installation package sets up and injects MIMIC's session replay recording functionality into your own application. Unfamiliar with MIMIC? Please visit our project links for more information!  

To properly utilize this installation package:
- Ensure your MIMIC backend is installed and running before proceeding.
- In the root folder of the desired application, run the installation script with `python3 -m mimic_replay.install` and follow the prompts. 